# WitIIC_JY901
姿态传感器IIC示例程序


https://wit-motion.yuque.com/wumwnr/ltst03/ws493a70fkn9wane?singleDoc# 《IIC协议-姿态传感器》



https://app.gitbook.com/s/7KeiQ2sbyWknusoV5r8U/iic-protocol