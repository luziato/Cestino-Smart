# 使用说明

文件夹名称为平台或者变成语言，使用前请按照您的所属平台和和所用编程语言来找对对应的文件夹

## 说明文档

https://wit-motion.yuque.com/wumwnr/ltst03/tw8xh2?singleDoc# 《Arduino_SDK快速入手》



# Instruction

The folder name is platform or language. Please find the corresponding folder according to your platform and programming language before using it

## Documentation

https://app.gitbook.com/s/7KeiQ2sbyWknusoV5r8U/iic-protocol/sdk/arduino_sdk-quick-start


